# Mesghal to Gram Converter

A simple Flutter app that converts weight from Mesghal to grams.

## Usage

1. Clone the repo.
2. Run `flutter pub get`.
3. Build the APK with:
   ```
   flutter build apk --release
   ```
4. The APK will be in `build/app/outputs/flutter-apk/app-release.apk`.
